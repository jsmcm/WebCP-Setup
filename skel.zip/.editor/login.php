<?php

session_start();
require_once($_SERVER["DOCUMENT_ROOT"]."/includes/functions.inc");

        if( ! isset($_GET["Nonce"]) )
        {
		print "Login failed or expired, please log into WebCP again and retry";
                exit();
        }


        if( ! isset($_GET["TimeStamp"]) )
        {
		print "Login failed or expired, please log into WebCP again and retry";
                exit();
        }


        $options2 = array(
                'uri' => 'http://localhost:10025',
                'location' => 'http://localhost:10025/API/nonce/nonce.php',
                'trace' => 1
        );


        $InputNonce = filter_var($_GET["Nonce"], FILTER_SANITIZE_STRING);

        $TimeStamp = filter_var($_GET["TimeStamp"], FILTER_SANITIZE_STRING);

        $MetaDataArray = array();
        array_push($MetaDataArray, $_SERVER["SERVER_ADDR"]);
        array_push($MetaDataArray, $_SERVER["SERVER_NAME"]);


        $client = new SoapClient(NULL, $options2);
        $Result = $client->VerifyNonce($InputNonce, "logInEditor", $TimeStamp, $MetaDataArray);

        if($Result == true)
        {
		SetLogin($InputNonce);
		header("location: index.php");
		exit();
	}

	print "Login failed or expired, please log into WebCP again and retry";
?>
