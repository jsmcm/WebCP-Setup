#! /bin/bash

Var=`/etc/init.d/exim status`

if [[ "$Var" =~ "running" ]]
then
        echo "running..."
else

	Password=`cat /usr/webcp/password`
	EmailAddress=$(mysql cpadmin -u root -p${Password} -se "SELECT email_address FROM admin WHERE deleted = 0 AND username = 'admin';")

        echo "not running"
        /etc/init.d/exim restart

	sleep 5
	Var2=`/etc/init.d/exim status`

        Var=`date`
        Var="$Var = exim was stopped"
        echo $Var >> /usr/webcp/services/exim_stopped.txt


	if [[ "$Var2" =~ "running" ]]
	then
		echo "On $Var, exim was stopped... I did and automatic restart and exim was successfully restarted!" | /usr/bin/mutt -s "EXIM RESTARTED!!!!" "$EmailAddress"
	else
		echo "On $Var, exim was stopped... I attempted an automatic restart but I could not restart exim!" | /usr/bin/mutt -s "EXIM STOPPED!!!!" "$EmailAddress"
	fi

	sleep 10
fi


