<?php

	if( ! isset($_GET["Nonce"]) )
	{
		exit();
	}
	
	
	if( ! isset($_GET["TimeStamp"]) )
	{
		exit();
	}
	

	$options2 = array(
		'uri' => 'http://localhost:10025',
		'location' => 'http://localhost:10025/API/nonce/nonce.php',
		'trace' => 1
	);


	$InputNonce = filter_var($_GET["Nonce"], FILTER_SANITIZE_STRING);
	
	$TimeStamp = filter_var($_GET["TimeStamp"], FILTER_SANITIZE_STRING);
	
	$MetaDataArray = array();
	array_push($MetaDataArray, $_SERVER["SERVER_ADDR"]);
	
	$client = new SoapClient(NULL, $options2);
	$Result = $client->VerifyNonce($InputNonce, "getUserCron", $TimeStamp, $MetaDataArray);

	if($Result == true)
	{
		print shell_exec("/usr/bin/crontab -l");	
	}
	
?>
