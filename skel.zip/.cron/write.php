<?php

	if( ! isset($_POST["Nonce"]) )
	{
		exit();
	}
	
	
	if( ! isset($_POST["TimeStamp"]) )
	{
		exit();
	}
	

	if( ! isset($_POST["CronData"]))
	{
		exit();
	}



	$options2 = array(
		'uri' => 'http://localhost:10025',
		'location' => 'http://localhost:10025/API/nonce/nonce.php',
		'trace' => 1
	);


	$InputNonce = filter_var($_POST["Nonce"], FILTER_SANITIZE_STRING);
	
	$TimeStamp = filter_var($_POST["TimeStamp"], FILTER_SANITIZE_STRING);
	
	$MetaDataArray = array();
	array_push($MetaDataArray, $_SERVER["SERVER_ADDR"]);
	
	$client = new SoapClient(NULL, $options2);
	$Result = $client->VerifyNonce($InputNonce, "saveUserCron", $TimeStamp, $MetaDataArray);

	if( $Result === false )
	{
		exit();
	}


	$File = $_SERVER["DOCUMENT_ROOT"]."/tmp_".date("Y-m-d_H-i-s")."_";
	$File = $File.rand(0,9);
	$File = $File.rand(0,9);
	$File = $File.rand(0,9);
	$File = $File.rand(0,9);
	$File = $File.rand(0,9);
	$File = $File.rand(0,9).".txt";

	file_put_contents($File, stripslashes($_POST["CronData"]));
	shell_exec("/usr/bin/crontab ".$File);

	unlink($File);

?>
