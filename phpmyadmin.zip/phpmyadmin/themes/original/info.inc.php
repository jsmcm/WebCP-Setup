<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * Theme information
 *
 * @package PhpMyAdmin-theme
 * @subpackage Original
 */

/**
 *
 */
$theme_name = 'Original';
$theme_full_version = '2.9';
?>
