<?php

if( ($_SERVER["REMOTE_ADDR"] != $_SERVER["SERVER_ADDR"]) )
{
  exit();
}

if(isset($_POST["HTAccessPath"]))
{
  $FileContent = $_POST["FileContent"];
    $HTAccessPath = $_POST["HTAccessPath"];
  $PasswordPath =$_POST["PasswordPath"];

  $f = fopen($HTAccessPath, "w");
    fwrite($f, $FileContent);
  fclose($f);
}

?>
