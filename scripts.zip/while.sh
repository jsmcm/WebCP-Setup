#!/bin/bash
while :
do
	echo "here"
	sleep 3
done
