for num in {1..10}
do	
	./for.sh &
	sleep 1
done

echo "Hi"
sleep 5
echo "bye"
