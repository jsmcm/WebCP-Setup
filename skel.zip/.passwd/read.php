<?php
if( ($_SERVER["REMOTE_ADDR"] != $_SERVER["SERVER_ADDR"]) )
{
        exit();
}
$Path = "";
if(isset($_POST["Path"]))
{
  $Path = $_POST["Path"];
}
if(file_exists($Path))
{
        print file_get_contents($Path);
}

?>
